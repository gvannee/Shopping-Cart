package hanu.a2_2001040222.mycart.models;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Constants {

    public static final ExecutorService executor = Executors.newFixedThreadPool(3);
}
